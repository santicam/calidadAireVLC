const navLinks = [
  { href: '/about', name: 'About' },
]

export default navLinks
