import Template from './HeroTemplate';

const Hero: React.FC = () => {
  return <Template />;
};

export default Hero;
