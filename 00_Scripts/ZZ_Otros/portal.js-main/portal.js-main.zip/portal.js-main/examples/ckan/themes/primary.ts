import { extend } from './utils';
import base from './base';

export default extend(base, {
  // Custom styles for primary theme
});
