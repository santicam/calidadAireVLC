# Portal.JS Default App

This example is the default, empty Portal.JS App.

## How to use

Execute [`create-next-app`](https://github.com/vercel/next.js/tree/canary/packages/create-next-app) with [npm](https://docs.npmjs.com/cli/init) or [Yarn](https://yarnpkg.com/lang/en/docs/cli/create/) to bootstrap the example:

```bash
npx create-next-app portaljs-default --use-npm --example https://github.com/datopian/portal.js/tree/main/examples/default
# or
yarn create next-app portaljs-default --example https://github.com/datopian/portal.js/tree/main/examples/default
```
